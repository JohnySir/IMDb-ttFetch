# IMDb ttFetch Extension — Implementation Plan

**Status:** Approved · **Version:** 1.1.0 · **Manifest:** Chrome MV3
**Author:** dev · **Last updated:** 2026-08-26

---

## 1. Overview

A lightweight Chrome extension (Manifest V3) that lets users copy the IMDb **Title ID**
(`tt` + 7–8 digits, e.g. `tt0111161`) from any IMDb page — movies, TV series,
episodes, video games, shorts — with one click, from a keyboard shortcut, from a
context menu, or from the extension popup.

The extension is read-only in its behavior toward IMDb: it never modifies page
content; it only *overlays* a small floating button and shows a transient "copied"
toast. No accounts, no telemetry, no remote requests.

### Why users need it

- Editors, data journalists, and app developers routinely reference titles by their
  IMDb ID (`tt` number) for APIs, datasets, and search queries.
- Manually copying the ID from the URL (or the title's `data-title-id` attribute)
  is error-prone: the URL is long, and the ID is easy to mistype.
- Many tools accept only the bare ID or only the `tt`-prefixed form; this extension
  lets the user choose the format.

---

## 2. Goals

| ID | Goal | Success criterion |
|----|------|-------------------|
| G1 | Copy the IMDb ID of the current page with one click | Floating button & popup expose a "Copy ID" action; toast confirms |
| G2 | Copy from a keyboard shortcut | `Ctrl+Shift+C` (`⌘+Shift+C` on macOS) copies the ID of the active tab |
| G3 | Copy from any selected text/page link | Context menu "Copy IMDb ID" resolves the ID from selection, page, or link URL |
| G4 | Support both ID formats | Option `tt1234567` (default) or bare `1234567` |
| G5 | Offline (page-only) behavior | All extraction is local; no runtime host permissions, no network calls |
| G6 | Recent-history convenience | Popup lists the last N copied IDs, each re-copyable with one click |
| G7 | Robust against IMDb redesigns | Extraction uses 5 independent strategies with a canonical-source priority order |

---

## 3. Non-Goals

- Searching IMDb or fetching metadata (needs network + user-data permissions; out of scope).
- Editing IMDb pages or injecting content beyond a dismissal-able overlay button.
- Wrapping IMDb for other sites / ID lookup from arbitrary text on *all* domains.
- Support for Firefox/Safari in v1 (manifest is MV3-Chrome-specific, but code layout
  keeps cross-browser porting possible).

---

## 4. Architecture

### 4.1 Component diagram

```
┌─────────────────────────── Chrome extension ───────────────────────────┐
│                                                                        │
│  manifest.json (MV3)                                                   │
│   └── permissions: clipboardWrite, storage, contextMenus, commands     │
│       host_permissions: https://www.imdb.com/* (+ http variant)        │
│                                                                        │
│  ┌──────────────┐   chrome.runtime.sendMessage   ┌───────────────────┐ │
│  │   content.js │ ───────────────────────────────▶ │  background.js   │ │
│  │  (isolated   │ ◀─────────────────────────────── │ (service worker) │ │
│  │   world,     │   background → content:          │  - context menus │ │
│  │   imdb.com)  │   {cmd:"COPY_ID"} etc.           │  - commands      │ │
│  └──────┬───────┘                                  │  - history       │ │
│         │ loads                                    │  - clipboard     │ │
│  ┌──────▼───────┐                                  │    fallback      │ │
│  │ src/imdb-id  │  (also imported by background    │                  │ │
│  │   .js        │   via importScripts)             └─────────┬────────┘ │
│  └──────┬───────┘                                           │ storage   │
│  ┌──────▼───────┐                                  ┌─────────▼────────┐ │
│  │  popup.html  │                                  │  options.html    │ │
│  │  popup.js    │  (chrome.storage + runtime)      │  options.js      │ │
│  └──────────────┘                                  └──────────────────┘ │
└─────────────────────────────────────────────────────────────────────────┘
```

### 4.2 Message flow

| # | Trigger | Path | Result |
|---|---------|------|--------|
| 1 | User clicks floating button | content.js resolves ID → `navigator.clipboard.writeText` → toast | ID in clipboard |
| 2 | Keyboard `Ctrl+Shift+C` | `commands` event → background → `tabs.sendMessage(tab, {cmd:"COPY_ID"})` → content copies | ID in clipboard |
| 3 | Context menu (selection) | `contextMenus.onClicked` → background extracts from `info.selectionText` via `importScripts`-loaded lib → clipboard | ID in clipboard |
| 4 | Context menu (link) | background extracts from `info.linkUrl` | ID in clipboard |
| 5 | Context menu (page) | background extracts from tab URL; fallback message to content | ID in clipboard |
| 6 | Popup copy | content not needed; popup shares clipboard context via `navigator.clipboard` | ID in clipboard |

### 4.3 The single source of truth

All ID extraction logic lives in **one classic script**:

- `src/imdb-id.js` — plain script that attaches `globalThis.IMDBLib`.
- Consumed by content (declared before `content.js` in the content-scripts array),
  the service worker (`importScripts("src/imdb-id.js")`), and the popup
  (`<script src="../src/imdb-id.js">`).

No module harness is needed; this keeps MV3 quirks (no DOM in the SW, classic
content script contexts) away from logic duplication.

---

## 5. Definitions & Data Model

### 5.1 ID grammar

```
IMDbID      = "tt" DIGIT{7,8}
normalized  = IMDbID | DIGIT{7,8}                    (depends on "format" option)
```

- Chained-title lookups: IMDb uses `tt…/tt…` in *episode* URLs — the **first** `tt…`
  in the URL path is the primary page subject; the regexes implement this.

### 5.2 Settings (`chrome.storage.sync`)

| Key | Type | Default | Meaning |
|-----|------|---------|---------|
| `idFormat` | `"tt" \| "digits"` | `"tt"` | Clipboard format |
| `showFloatingButton` | `boolean` | `true` | Show the overlay button |
| `menuEnabled` | `boolean` | `true` | Context menu on/off |
| `toastDurationMs` | `number` | `1400` | Simmer display time |
| `historySize` | `number` | `10` | Max recent entries |

### 5.3 History (`chrome.storage.local` → `history` array)

```json
{ "id": "tt0111161", "title": "The Shawshank Redemption", "copiedAt": 1710000000000 }
```

Cap = `historySize`; newest first; identical IDs dedupe by replacing the older entry.

---

## 6. Component Detail

### 6.1 `manifest.json`

```jsonc
{
  "manifest_version": 3,
  "name": "IMDb ID Copy",
  "version": "1.0.0",
  "description": "Copy IMDb IDs (tt…) with one click, a keyboard shortcut, or the context menu.",
  "permissions": ["storage", "contextMenus", "clipboardWrite", "commands"],
  "host_permissions": ["https://www.imdb.com/*", "http://www.imdb.com/*"],
  "background": { "service_worker": "src/background.js" },
  "content_scripts": [{
    "matches": ["https://www.imdb.com/*", "http://www.imdb.com/*"],
    "js": ["src/imdb-id.js", "src/content.js"],
    "run_at": "document_idle",
    "all_frames": false
  }],
  "action": { "default_popup": "src/popup.html", "default_icon": {…} },
  "options_page": "src/options.html",
  "commands": {
    "copy-imdb-id": {
      "suggested_key": { "default": "Ctrl+Shift+C", "mac": "Command+Shift+C" },
      "description": "Copy IMDb ID of current page"
    }
  },
  "icons": { "16": "icons/icon16.png", "48": "icons/icon48.png", "128": "icons/icon128.png" }
}
```

**Permissions rationale**

| Permission | Why |
|------------|-----|
| `storage` | settings + copy history |
| `contextMenus` | right-click menu items |
| `clipboardWrite` | clipboard writes from the service worker (no clipboard read ever) |
| `commands` | keyboard shortcut |
| `host_permissions` | content script injection; no other site access, no `<all_urls>` |

No `offscreen` permission is declared by default; a fallback clipboard path via
`navigator.clipboard` in the SW is sufficient for MV3 service workers with
`clipboardWrite`. (An offscreen-document fallback is noted in §10 as an optional
future hardening step, code-gated behind a flag, not shipped by default.)

**Security note:** the extension stores only the page URL + title for history; it
never sends data anywhere, and content scripts are isolated from the IMDb page's JS
world (content scripts run in an isolated world).

### 6.2 `src/imdb-id.js`

Public API (`window.IMDBLib`):

- `extractFromUrl(url) → string | null`
  - Parses URL, hostname must end with `imdb.com`; else `null`.
  - Regex on `pathname`: `/\/title\/(tt\d{7,8})/` → the first match (primary subject for `/title/tt…/…`).
- `extractFromText(text) → string | null`
  - `/\b(tt\d{7,8})\b/` over arbitrary text (used for selection context menu).
- `collectFromDocument(doc) → string | null`
  - Priority order (canonical source list):
    1. `link[rel="canonical"]` href
    2. `meta[property="og:url"]` content
    3. `meta[property="og:title"]` / `meta[name="twitter:title"]` content (may contain the id)
    4. `#__NEXT_DATA__` script JSON — `props.pageProps.aboveTheFold.runtime.id` / `…meta` (IMDb is Next.js)
    5. `document.title`
    6. `location.href`
  - Returns the first non-null.
- `formatId(id, format)` → id with or without `tt` prefix.
- `isImdbHost(url)` → boolean.

Status: pattern-tested with a unit-style assertion set (see §11 testing).

### 6.3 `src/content.js`

Responsibilities:

1. **Resolve id** via `IMDBId.collectFromDocument(document)`.
2. **Floating button** (only when `showFloatingButton`)
   - Shadow-DOM-hosted `<button>` styled with IMDb-gold; fixed bottom-right,
     `z-index 2147483640`, `aria-label` copy title.
   - On click: copy id + notify.
3. **Toast**: tiny gold/dark pill near the button; shows "Copied tt0111161" for
   `toastDurationMs`, animates in/out with CSS.
4. **Message listener** (`chrome.runtime.onMessage`):
   - `{cmd:"COPY_ID"}` → resolve & copy (from the keyboard command fast path),
     reply `{ok,id,format}`.
   - `{cmd:"GET_ID"}` (popup/context fallback) → reply with resolved id + page title.
   - `{cmd:"PING"}` → `{alive:true}` so the SW knows a content script exists.
5. **Settings subscription**: `chrome.storage.onChanged` re-renders / hides button
   live without reload.

Edge-case behavior:

- If the title 'id' can't be resolved (`collectFromDocument` returns null), the
  button is not shown and toast instead says "No IMDb ID found on this page".
- On non-IMDb page load the script simply no-ops (host pattern already restricts).

### 6.4 `src/background.js`

```js
importScripts("src/imdb-id.js");
```

State:

- Cache the current settings in memory; init from `chrome.storage` on `onInstalled` /
  `runtime.startup` etc.
- Keep a context-menu entry `“Copy IMDb ID”` (enabled per `menuEnabled`), with
  contexts `["page", "selection", "link"]`; the label stays constant so it can be
  updated once.

Commands:

- `copy-imdb-id` → `chrome.tabs.query({active:true,currentWindow:true})`.
  - If `tab.url` is an IMDb URL → compute id from URL (fast path) **and** send a
    `COPY_ID` message to the content script so the local-`_toast` shows:
    - `COPY_ID` fails → fall back to SW-side `navigator.clipboard.writeText(id)`.
  - Non-IMDb URL → toastNotPractionally notify popup (id-based) — send the id to
    popup via storage event / `chrome.notifications`? The popup isn't open; we skip
    and return `{ok:false,reason:"not-imdb"}`.

Context menu handler (`onClicked`):

- `info.menuItemId === "copy-imdb-id"`:
  - `info.selectionText` → `extractFromText` (also, if that yields null, fall back to `linkUrl` then to the page.)
  - `info.linkUrl` → `extractFromUrl`.
  - else → `info.pageUrl` → `extractFromUrl`.
- Then `navigator.clipboard.writeText(formatted)`.
  - MV3 SW `navigator.clipboard` works with `clipboardWrite`; wrap in try/catch with
    a legacy fallback `document.execCommand` via an offscreen page (added behind
    `USE_OFFSCREEN_FALLBACK` flag; the flag is off until we see evidence of a
    failure of the default path).
- Every successful copy appends to history (`chrome.storage.local`).

### 6.5 `src/popup.html/js/css`

Layout (small, ~320px wide, dark IMDb theme):

```
┌───────────────────────────┐
│ ⭐ IMDb ID Copy            │
│                           │
│ Current page              │
│ ┌───────────────────────┐ │
│ │ tt0111161        ⧉   │ │
│ └───────────────────────┘ │
│  Title: The Shawshank…    │
│                           │
│ ── Recently copied ──     │
│  tt0936501  · 2m ago  ⧉  │
│  tt0111161  · 8m ago  ⧉  │
│  …                        │
│                        [Clear] │
│ ⚙ Options                 │
└───────────────────────────┘
```

Behavior:

- On open: get active tab → `chrome.tabs.sendMessage(tabId,{cmd:"GET_ID"})`.
  - If no content script: derive from `tab.url` via `extractFromUrl`.
- "Copy" buttons:
  - Use a DOM `<input>` value + `select()` + `navigator.clipboard.writeText` with
    focus fallback (document.execCommand each) to be robust in popup context.
  - Visual "✓ Copied" feedback for 1s.
- History: `chrome.storage.local` → render up to `historySize` items with relative
  timestamps; click copies; `Clear` empties.
- `⚙ Options` opens `options.html` in a new tab.
- Live-sync: settings changes re-render.

### 6.6 `src/options.html/js/css`

Form fields (all persisted to `storage.local` and applied instantly):

- ID format — `<select>`: `tt` prefix vs digits only. Show a preview box that
  renders the choice live (e.g., I type expected).
- Toast duration — number slider 500–5000 ms.
- Show floating button — checkbox.
- Enable context menu — checkbox.
- History size — number input 0–50.
- Buttons: **Save changes** (confirmation), **Reset to defaults**.
- Footer: extension version from `chrome.runtime.getManifest()`; link "View plan.md".

Validation: warn if inputs out-of-range; save atomic; `storage.onChanged` in opened
content scripts applies immediately.

---

## 7. Clipboard strategy decision (detailed)

| Context | Strategy | Priority |
|---------|----------|----------|
| Content script (user gesture) | `navigator.clipboard.writeText` | 1 |
| Popup (user gesture) | focused temp textarea + `document.execCommand("copy")`; fallback `navigator.clipboard` | 1 |
| Service worker (context menu click counts as gesture in MV3 with `clipboardWrite`) | `navigator.clipboard.writeText` | 1 |
| Service worker fallback | Offscreen document (`chrome.offscreen`) with textarea + execCommand | 2 (flag-gated) |

No clipboard **reading** permission is requested — the extension never touches the
user's existing clipboard content.

---

## 8. Iconography

Simple, recognizable mark generated as PNGs (`16/48/128`):

- Dark navy rounded square background (#11141d).
- IMDb-gold (#f5c518) `ID` glyph / minor "tt" tag.
- Consistent geometry rasterized per size so small sizes stay legible.
- `icons/` folder; generated programmatically (see §10.4) and committed.

---

## 9. Edge Cases & Handling

| Case | Behavior |
|------|----------|
| Non-IMDb tab + shortcut | Toast-driven message not sent; SW replies `{ok:false, reason:"not-imdb"}`; popup informs user |
| Page is IMDb but the ID is missing | Button hidden unless forced; toast = "No IMDb ID found" |
| `tt` with wrong length | Rejected (7–8 digits only) |
| URL `…/title/tt1234567/tt0987654/` (related-title links) | Primary = first `tt…` match; manual note may mention episode id |
| Frame / iframe embeds | `all_frames:false` — only the top frame overlay+re rule |
| Permissions prompt friction | We chose `host_permissions` (install-time prompt); no additional runtime requests |
| Settings changed while open | Live via `storage.onChanged` |
| History overflow | Trim to cap; oldest dropped |
| Chrome version < 88 (MV3 unsupported) | N/A — min Chrome 88+ |
| `navigator.clipboard` unavailable (e.g., insecure context) | execCommand fallback path |

---

## 10. Build & Icon generation

### 10.1 Layout sketch

```
imdb-id-copy/
├── plan.md
├── README.md
├── manifest.json
├── icons/
│   ├── icon16.png / icon48.png / icon128.png
└── src/
    ├── imdb-id.js
    ├── content.js
    ├── background.js
    ├── popup.html / popup.js / popup.css
    └── options.html / options.js / options.css
```

### 10.2 Non-build (MV3, load-unpacked)

No preprocessors, no bundlers, no CI — plain JS ES5-ish for maximum chrome
compatibility (uses `let/const`, arrow funcs fine on Chrome 88+).

Verification steps:

1. `chrome://extensions` → Developer mode → **Load unpacked** → select repo root.
2. Visit `https://www.imdb.com/title/tt0111161/` → icon button visible & gold.
3. Click → toast → clipboard contains `tt0111161` (paste check).
4. `Ctrl+Shift+C` on 一部 ms IMDb page → copied.
5. Right click a page → context menu → Copy IMDb ID.
6. Options: switch to digit-only, repeat 2–4 expect `0111161` (7+ digits, no `tt`).
7. Reopen browser, history persisted.

### 10.3 Automated smoke test (optional, node available)

Script `test/id-lib.test.mjs` imports `imdb-id.js` as a plain module via a small
shim and asserts the idiom cases from §9. Running `node test/id-lib.test.mjs`
is a dev convenience; it is **not** part of the package.

### 10.4 Icon generation script

`tools/make-icons.ps1` uses `System.Drawing` to rasterize the design at 16/48/128,
run once and committed (icons are binary assets; no runtime generation).

---

## 11. Rollout & Packaging

1. **Dev** — load unpacked, run §10.2 checklist.
2. **Zip** for distribution: `Compress-Archive` of `manifest.json`, `src/`, `icons/`,
   `README.md`, `plan.md` at the root (no node_modules, no tests in the zip).
3. **Chrome Web Store** upload (names), store listing assets (screenshot of popup +
   overlay on an IMDb page), one-sentence privacy note: "No data leaves the
   browser." Category: Productivity.
4. Post-store: version bump to 1.1.0 on feature additions (format "edge" option).

---

## 12. Risks & Mitigations

| Risk | Likelihood | Mitigation |
|------|-----------|------------|
| IMDb markup changes | Med, they cms frequently | 6 canonical/extraction strategies; simple, documented regex layer |
| Service-worker clipboard flakiness | Low | execCommand offscreen fallback path (flag-gated) |
| `Ctrl+Shift+C` conflicts with other extensions | Low | documented setting: user can remap in `chrome://extensions/shortcuts` |
| Review friction in Web Store | Low | No `<all_urls>`, no analytics, minimal-scope host permission |
| History PII concerns | Low | History stores only the ID + copied-page title if derived; no tracking |

---

## 13. Definition of Done

- [x] High-level plan (this document) exists and is followed
- [ ] `manifest.json` loads in stable Chrome with zero warnings
- [ ] All 5 copy paths return the same, correct backend `tt…` string
- [ ] Options page toggles live
- [ ] Context menu, shortcut, button, popup all tested manually (§10.2)
- [ ] README documents install + usage + shortcuts remap + store policies compliance
- [ ] Icons render crisp at 16/48/128
- [ ] Final zip archive produced in `dist/imdb-id-copy.zip`