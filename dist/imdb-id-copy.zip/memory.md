# Project Memory: IMDb ttFetch Extension

**Last Updated:** 2026-08-26  
**Version:** 1.1.0  
**Target Platform:** Chromium Manifest V3 (Chrome, Edge, Brave, Opera, Vivaldi)  
**Type:** Browser Extension (Vanilla JavaScript / Zero Build Step)  
**Repositories:**
- Development / Working Directory: `E:\GitHub\IMDB ID Copy Extension`
- Release & Git Repository: `E:\GitHub\IMDb-ttFetch`

---

## 1. Executive Summary & Purpose

**IMDb ttFetch** is a lightweight, zero-telemetry, privacy-first Chrome Extension (Manifest V3) designed to fetch and copy IMDb Title IDs (`tt1234567` or `1234567`), format movie/series title metadata, and provide instant sneak peek access to the Parents Guide / Content Advisory with zero friction.

### Key Features
- 🖱️ **Floating Action Buttons:** Injected via Shadow DOM on IMDb title pages:
  - `★ Copy IMDb ID`: Copies formatted IMDb ID.
  - `★ Copy Title`: Copies clean title with or without release year.
  - `★ Parents Guide`: Jumps directly to `https://www.imdb.com/title/{imdb_id}/parentalguide/`. If no Parents Guide exists (marked on IMDb by "Add content advisory"), the button is automatically grayed out with a `not-allowed` cursor.
  - `👁 Peek`: Paired side-by-side with Parents Guide. Opens a smooth content rating popup with a loading animation, color-coded severity bars (Mild/None=Green, Moderate=Yellow, Severe=Red), and category filters.
- ⌨️ **Global Keyboard Shortcut:** `Ctrl+Shift+C` (`Command+Shift+C` on macOS) to fetch and copy the active tab's IMDb ID.
- 🖱️ **Context Menu:** Right-click on any page, link, or selected text to copy matching IMDb IDs.
- 🧩 **Action Popup:** Displays active tab's resolved ID and title, instant copy buttons, and recent copy history with relative timestamps.
- ⚙️ **Configurable Formats & Toggles:**
  - **ID Format:** `tt`-prefixed (`tt0111161`) or Digits-only (`0111161`).
  - **Title Format:** `Title Year` (e.g. `Inception 2010`, `Breaking Bad 2008`) or `Just Title` (e.g. `Inception`, `Breaking Bad`).
  - **Sneak Peek Rating Categories:** Independently toggle Sex & Nudity, Violence & Gore, Profanity, Alcohol/Drugs/Smoking, and Frightening/Intense Scenes.
  - **Button Toggles:** Independently toggle Copy ID, Copy Title, Parents Guide, and Sneak Peek buttons.
- 🔄 **Instant Reload on Save:** Saving options automatically triggers `chrome.runtime.reload()` so changes take effect immediately without manual extension reloading.
- 🚀 **High Performance & Low Resource:** Multi-tier short-circuit metadata extractors, $O(1)$ AST traversals with `Set`, event-driven SPA navigation handling, and DOM batching with `DocumentFragment`.

---

## 2. Codebase Structure & File Map

```
IMDb-ttFetch/
├── manifest.json              # Chrome MV3 manifest declaration & permissions
├── README.md                  # Public documentation, usage, and personal use notice
├── LICENSE                    # MIT open-source license
├── .gitignore                 # Ignore rules for dist, OS, and IDE artifacts
├── plan.md                    # Technical architectural specification & design document
├── memory.md                  # Living memory file & reference for modifications
│
├── src/
│   ├── imdb-id.js             # Core extraction library & SSoT (Classic JS / universal)
│   ├── content.js             # Content script (Shadow DOM buttons, Sneak Peek modal, SPA observer)
│   ├── background.js          # Service Worker (Context menus, shortcuts, history, fetch relay)
│   ├── popup.html             # Extension browser action popup markup
│   ├── popup.js               # Popup logic (active tab query, clipboard, history list)
│   ├── popup.css              # Dark theme styling for popup UI
│   ├── options.html           # Settings / options page markup
│   ├── options.js             # Options logic (sync storage load/save/reset, validation, reload)
│   └── options.css            # Settings page styling
│
├── icons/
│   ├── icon16.png             # 16x16 icon
│   ├── icon32.png             # 32x32 icon
│   ├── icon48.png             # 48x48 icon
│   └── icon128.png            # 128x128 icon
│
├── test/
│   └── id-lib.test.mjs        # Automated smoke test suite (82 tests across all extractors)
│
├── tools/
│   └── make-icons.ps1         # PowerShell icon generator script using System.Drawing
│
└── dist/
    ├── imdb-ttfetch.zip       # Packaged release archive
    └── imdb-id-copy.zip       # Legacy compatibility archive
```

---

## 3. Component Architecture & Data Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                            CHROME EXTENSION (MV3)                           │
│                                                                             │
│  manifest.json                                                              │
│  ├── Permissions: storage, contextMenus, clipboardWrite, commands          │
│  └── Host Permissions: https://www.imdb.com/*, http://www.imdb.com/*       │
│                                                                             │
│  ┌─────────────────────────┐                ┌────────────────────────────┐  │
│  │       content.js        │ ◄──Messages──► │       background.js        │  │
│  │ (Isolated World on IMDb)│                │      (Service Worker)      │  │
│  │  - Shadow DOM UI        │  COPY_ID,      │  - Context Menus           │  │
│  │  - Floating Buttons     │  GET_ID,       │  - Commands Listener       │  │
│  │  - Sneak Peek Modal     │  GET_TITLE,    │  - History Management      │  │
│  │  - Toast Notifications  │  FETCH_PG,     │  - Advisory Fetch Relay    │  │
│  │  - Event-Driven SPA     │  COPIED        │  - Clipboard Fallback      │  │
│  └────────────┬────────────┘                └─────────────┬──────────────┘  │
│               │                                           │                 │
│               ▼                                           ▼                 │
│  ┌─────────────────────────┐                ┌────────────────────────────┐  │
│  │     src/imdb-id.js      │                │   chrome.storage.sync      │  │
│  │ (Shared Universal Lib)  │                │   chrome.storage.local     │  │
│  └────────────▲────────────┘                └─────────────▲──────────────┘  │
│               │                                           │                 │
│  ┌────────────┴────────────┐                ┌─────────────┴──────────────┐  │
│  │       popup.js          │                │        options.js          │  │
│  │ (Action Popup UI)       │                │ (Settings & Preferences)   │  │
│  └─────────────────────────┘                └────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Extraction Engine (`src/imdb-id.js`)

All extraction logic is centralized in `src/imdb-id.js`, exposed under `globalThis.IMDBId` / `window.IMDBId`.

### Key Regex Patterns
- `ID_REGEX = /\btt\d{7,8}\b/`
- `TITLE_PATH_REGEX = /\/title\/(tt\d{7,8})\b/`
- `SERIES_TYPE_RE = /series|miniseries|tvseries|tvmini|tvepisode/i`
- `ORIGINAL_PREFIX_RE = /^\s*original\s*title\s*:\s*/i`

### ID Extraction Strategies (`collectFromDocument`)
1. `link[rel="canonical"]` (Short-circuit return)
2. `meta[property="og:url"]` (Short-circuit return)
3. `meta[property="og:title"]`, `meta[name="twitter:title"]`
4. `#__NEXT_DATA__` JSON parse: recursive AST traversal (depth $\le 6$) with $O(1)$ `Set` deduplication.
5. `document.title`
6. `document.location.href`

### Title & Year Extraction Strategies (`extractTitleInfoFromDocument`)
1. `application/ld+json` script tag: extracts `name`, `alternateName`, `datePublished` (ISO and year ranges), and `@type`.
2. DOM Hero elements: `h1[data-testid="hero__pageTitle"]`, metadata spans, original title containers, and parent tag fallbacks.
3. `__NEXT_DATA__` JSON: extracts `titleText.text`, `originalTitleText.text`, `releaseYear.year`, `releaseYear.endYear`, and series types.
4. Fallback: parses `document.title` or `og:title` removing IMDb suffixes.

### Parents Guide Availability & Ratings Extraction (`detectParentsGuide`, `extractParentsGuideRatings`)
1. **`detectParentsGuide(doc)`:**
   - Detects `"Add content advisory"` or `"Be the first to add"` in links/buttons $\rightarrow$ `false` (disabled button).
   - Scans advisory sections for active severity categories (`Mild`, `Moderate`, `Severe`, `None`) $\rightarrow$ `true`.
   - Inspects `__NEXT_DATA__` for `parentsGuide.categories` length and `totalCount`.
2. **`extractParentsGuideRatings(docOrHtml)` (3-Tier Engine):**
   - **Tier 1 (Authoritative Next.js & GraphQL Tree Inspection):** Recursively traverses `__NEXT_DATA__` objects (`inspectNextDataItem`) checking nested fields (`category.text`, `category.id`, `severity.text`, `severity.id`, `severityType.text`).
   - **Tier 2 (Specific DOM Badge Extraction):** Selects exact advisory metadata list items and their value badges (`[class*="content-item"]`, `[data-testid*="severity"]`), avoiding commentary body texts.
   - **Tier 3 (Strict Proximity Regex Scan):** Scans page/HTML text with strict token proximity patterns:
     - `/(?:sex\s*(?:&|and)\s*nudity|\bnudity\b)[^a-zA-Z0-9<>{}\[\]]{0,20}\s*\b(Severe|Moderate|Mild|None)\b/i`
     - Prevents false "None" matches from commentary phrases (e.g. *"none of which is sexual"*).
   - **Severity Normalization:** Standardizes into `{ severity: 'Mild'|'Moderate'|'Severe'|'None'|'Not Rated', level: 'mild'|'moderate'|'severe'|'none'|'unknown' }`.

### Formatting Functions
- `formatId(id, format)`:
  - `format === 'digits'` $\rightarrow$ strips `^tt`
  - `format === 'tt'` (default) $\rightarrow$ guarantees `tt` prefix
- `buildTitleString(info, format)`:
  - `format === 'title-year'` (default): Returns `Title [OriginalTitle] Year` (e.g. `Inception 2010`, `Breaking Bad 2008`, `Parasite 기생충 2019`).
  - `format === 'title'`: Returns `Title [OriginalTitle]` without year (e.g. `Inception`, `Breaking Bad`, `Parasite 기생충`).

---

## 5. Storage Model & Defaults

### 1. `chrome.storage.sync` (Settings)
| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `idFormat` | `"tt" \| "digits"` | `"tt"` | Output format for IMDb ID |
| `titleFormat` | `"title-year" \| "title"` | `"title-year"` | Output format for Title copy (`Title Year` vs `Just Title`) |
| `showFloatingButton` | `boolean` | `true` | Show floating "Copy IMDb ID" button on page |
| `showTitleButton` | `boolean` | `true` | Show floating "Copy Title" button on page |
| `showParentsGuideButton` | `boolean` | `true` | Show floating "Parents Guide" button on page |
| `showSneakPeekButton` | `boolean` | `true` | Show paired "👁 Peek" button next to Parents Guide |
| `peekCatNudity` | `boolean` | `true` | Show "Sex & Nudity" rating in Sneak Peek |
| `peekCatViolence` | `boolean` | `true` | Show "Violence & Gore" rating in Sneak Peek |
| `peekCatProfanity` | `boolean` | `true` | Show "Profanity" rating in Sneak Peek |
| `peekCatAlcohol` | `boolean` | `true` | Show "Alcohol, Drugs & Smoking" rating in Sneak Peek |
| `peekCatFrightening` | `boolean` | `true` | Show "Frightening & Intense Scenes" rating in Sneak Peek |
| `menuEnabled` | `boolean` | `true` | Enable context menu item in Chrome |
| `toastDurationMs` | `number` | `1400` | Duration (ms) toast notification stays visible (min 500, max 5000) |
| `historySize` | `number` | `10` | Maximum number of recent items to retain (min 0, max 50) |

### 2. `chrome.storage.local` (Copy History)
- Key: `history`
- Schema: Array of objects:
  ```json
  [
    {
      "id": "tt0111161",
      "rawId": "tt0111161",
      "title": "The Shawshank Redemption",
      "url": "https://www.imdb.com/title/tt0111161/",
      "copiedAt": 1740500000000
    }
  ]
  ```
- Deduped by ID (moving re-copied items to the top), capped at `historySize`.

---

## 6. Messaging Protocol

| Message Command / Type | Sender $\rightarrow$ Receiver | Payload | Response / Action |
|---|---|---|---|
| `{ cmd: "COPY_ID", explicitId?: string }` | Background/Popup $\rightarrow$ Content | Optional explicit ID | Resolves ID, writes to clipboard, displays toast, records history, responds with `{ ok, raw, id, title, copied }`. |
| `{ cmd: "GET_ID" }` | Popup $\rightarrow$ Content | None | Resolves ID from document/URL without copying; responds with `{ ok, raw, id, title }`. |
| `{ cmd: "GET_TITLE", titleFormat?: string }` | Popup/Background $\rightarrow$ Content | Optional format | Resolves title info and formatted string; responds with `{ ok, titleInfo, text }`. |
| `{ cmd: "FETCH_PARENTS_GUIDE", id: string }` | Content $\rightarrow$ Background | IMDb ID (`rawId`) | Fetches and parses Parents Guide ratings for sneak peek; responds with `{ ok, categories, cached }`. |
| `{ cmd: "PING" }` | Any $\rightarrow$ Content | None | Responds with `{ alive: true, id }`. |
| `{ type: "COPIED", ... }` | Content $\rightarrow$ Background | `{ id, rawId, title, url }` | Background appends item to `chrome.storage.local` history. |
| `{ type: "COMMAND_RESULT", ... }` | Background $\rightarrow$ Popup/Runtime | `{ ok, id, reason }` | Broadcasts outcome of shortcut command execution. |

---

## 7. Performance & Optimization Architecture

1. **Short-Circuit Metadata & ID Resolution:**
   - Evaluates lightweight canonical link / `og:url` / JSON-LD first, resolving in $< 0.1\text{ms}$ on 99% of pages without parsing heavy Next.js payloads.
2. **Instant Sneak Peek Hydration & Background Cache:**
   - Content script inspects in-page `__NEXT_DATA__` first for instantaneous zero-latency rating preview; falls back to background service worker fetch with in-memory session caching.
3. **$O(1)$ Visited Set Traversal:**
   - Uses native `Set` for visited nodes in recursive walks, avoiding linear array searches and deep memory overhead.
4. **Event-Driven SPA Navigation:**
   - Uses `popstate`, Navigation API, and `MutationObserver` on `<title>` with debounce, replacing polling with near-zero idle CPU usage.
5. **DOM Batching:**
   - Uses `DocumentFragment` in popup history rendering to eliminate reflow overhead.
6. **Defensive Callback Handling:**
   - All async storage/message responses guard callbacks with `if (typeof cb === 'function')`.

---

## 8. Testing & Quality Assurance

- **Unit Smoke Tests:** `test/id-lib.test.mjs`
  - Runs natively with Node.js via `node test/id-lib.test.mjs`.
  - Simulates DOM, JSON-LD, `__NEXT_DATA__` ASTs, fallback titles, format permutations, Parents Guide availability detection, and rating category extractions across 82 assertions.
- **Current Test Status:** **82 passed, 0 failed**.
