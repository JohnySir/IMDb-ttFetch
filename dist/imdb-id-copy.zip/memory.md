# Project Memory: IMDb ttFetch Extension

**Created:** 2026-08-25  
**Version:** 1.1.0  
**Target Platform:** Chromium Manifest V3 (Chrome, Edge, Brave, Opera, Vivaldi)  
**Type:** Browser Extension (Vanilla JavaScript / No Build Step)

---

## 1. Executive Summary & Purpose

**IMDb ttFetch** is a privacy-first, zero-telemetry Chrome Extension (Manifest V3) designed to fetch and copy IMDb Title IDs (`tt1234567` or `1234567`) and formatted Title information with minimal friction.

### Key Capabilities
- **Floating Action Buttons:** Injected directly on IMDb pages via Shadow DOM (`★ Copy IMDb ID` and `★ Copy Title`).
- **Global Keyboard Shortcut:** `Ctrl+Shift+C` (`Command+Shift+C` on macOS) to fetch and copy the active tab's IMDb ID instantly.
- **Context Menu Integration:** Right-click on pages, selected text, or links to copy matching IMDb IDs.
- **Action Popup:** Displays active tab's resolved ID and title, instant copy buttons, and recent copy history with relative timestamps.
- **Options / Configuration:** Configurable ID formatting (`tt` prefix vs bare digits), Title formatting (`Title Year` vs `Just Title`), UI toggle switches, toast duration, and history cap.
- **Title Information Extractor:** Parses English/international titles, original titles, release years, and detects TV/series formats.

---

## 2. Codebase Structure & File Map

```
IMDB ID Copy Extension/
├── manifest.json              # Chrome MV3 manifest declaration & permissions
├── README.md                  # Public documentation, installation guide, privacy details
├── plan.md                    # Technical architectural specification & design document
├── memory.md                  # Living memory file & reference for modifications
│
├── src/
│   ├── imdb-id.js             # Core extraction library & SSoT (Classic JS / universal)
│   ├── content.js             # Content script (Shadow DOM buttons, toast, SPA observer)
│   ├── background.js          # Service Worker (Context menus, shortcuts, history, clipboard)
│   ├── popup.html             # Extension browser action popup markup
│   ├── popup.js               # Popup logic (active tab query, clipboard, history list)
│   ├── popup.css              # Dark theme styling for popup UI
│   ├── options.html           # Settings / options page markup
│   ├── options.js             # Options logic (sync storage load/save/reset, validation)
│   └── options.css            # Settings page styling
│
├── icons/
│   ├── icon16.png             # 16x16 icon
│   ├── icon48.png             # 48x48 icon
│   └── icon128.png            # 128x128 icon
│
├── test/
│   └── id-lib.test.mjs        # Automated smoke test suite for imdb-id.js (Node.js vm)
│
├── tools/
│   └── make-icons.ps1         # PowerShell icon generator script using System.Drawing
│
└── dist/
    └── imdb-id-copy.zip       # Packaged release archive
```

---

## 3. Component Architecture & Data Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                            CHROME EXTENSION (MV3)                           │
│                                                                             │
│  manifest.json                                                              │
│  ├── Permissions: storage, contextMenus, clipboardWrite, commands          │
│  └── Host Permissions: https://www.imdb.com/*, http://www.imdb.com/*       │
│                                                                             │
│  ┌─────────────────────────┐                ┌────────────────────────────┐  │
│  │       content.js        │ ◄──Messages──► │       background.js        │  │
│  │ (Isolated World on IMDb)│                │      (Service Worker)      │  │
│  │  - Shadow DOM UI        │  COPY_ID,      │  - Context Menus           │  │
│  │  - Floating Buttons     │  GET_ID,       │  - Commands Listener       │  │
│  │  - Toast Notifications  │  GET_TITLE,    │  - History Management      │  │
│  │  - SPA URL Poller       │  COPIED        │  - Clipboard Fallback      │  │
│  └────────────┬────────────┘                └─────────────┬──────────────┘  │
│               │                                           │                 │
│               ▼                                           ▼                 │
│  ┌─────────────────────────┐                ┌────────────────────────────┐  │
│  │     src/imdb-id.js      │                │   chrome.storage.sync      │  │
│  │ (Shared Universal Lib)  │                │   chrome.storage.local     │  │
│  └────────────▲────────────┘                └─────────────▲──────────────┘  │
│               │                                           │                 │
│  ┌────────────┴────────────┐                ┌─────────────┴──────────────┐  │
│  │       popup.js          │                │        options.js          │  │
│  │ (Action Popup UI)       │                │ (Settings & Preferences)   │  │
│  └─────────────────────────┘                └────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Single Source of Truth (`src/imdb-id.js`)

All extraction logic is centralized in `src/imdb-id.js`, exposed under `globalThis.IMDBId` / `window.IMDBId`.

### Key Functions & Regex
- **Regex Patterns:**
  - `ID_REGEX = /\btt\d{7,8}\b/`
  - `TITLE_PATH_REGEX = /\/title\/(tt\d{7,8})\b/`
  - `SERIES_TYPE_RE = /series|miniseries|tvseries|tvmini|tvepisode/i`
  - `ORIGINAL_PREFIX_RE = /^\s*original\s*title\s*:\s*/i`

### ID Extraction Strategies & Priority Order (`collectFromDocument`)
1. `link[rel="canonical"]` (`href` attribute)
2. `meta[property="og:url"]` (`content` attribute)
3. `meta[property="og:title"]`, `meta[name="twitter:title"]` (`content` attribute)
4. `#__NEXT_DATA__` JSON parse: recursive AST traversal (depth $\le 6$) inspecting keys `id`, `titleId`, `tconst`, `title`, and objects `aboveTheFold`, `meta`, etc.
5. `document.title`
6. `document.location.href`

### Title Info Extraction Strategies (`extractTitleInfoFromDocument`)
1. `__NEXT_DATA__` JSON: extracts `titleText.text`, `originalTitleText.text`, `releaseYear.year`, `releaseYear.endYear`, and series indicators.
2. `application/ld+json` script tag: extracts `name`, `alternateName`, `datePublished`, and `@type`.
3. DOM Hero elements: `h1[data-testid="hero__pageTitle"]`, `[data-testid="hero-title-block__metadata"]`, original title containers.
4. Fallback: parses `document.title` or `og:title` removing IMDb suffixes and parsing years/series tags.

### Output Formatting
- `formatId(id, format)`:
  - `format === 'digits'` $\rightarrow$ strips `^tt`
  - `format === 'tt'` $\rightarrow$ guarantees `tt` prefix
- `buildTitleString(info)`:
  - If `isSeriesLike`: formats as `Title` (or `Title OriginalTitle` if different), omitting year.
  - If movie / non-series: formats as `Title [OriginalTitle] Year` (space-separated, duplicates omitted).

---

## 5. Storage Model & Defaults

### 1. `chrome.storage.sync` (Settings)
| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `idFormat` | `"tt" \| "digits"` | `"tt"` | Output format for IMDb ID |
| `titleFormat` | `"title-year" \| "title"` | `"title-year"` | Output format for Title copy (`Title Year` vs `Just Title`) |
| `showFloatingButton` | `boolean` | `true` | Show floating "Copy IMDb ID" button on page |
| `showTitleButton` | `boolean` | `true` | Show floating "Copy Title" button on page |
| `menuEnabled` | `boolean` | `true` | Enable context menu item in Chrome |
| `toastDurationMs` | `number` | `1400` | Duration (ms) toast notification stays visible (min 500, max 5000) |
| `historySize` | `number` | `10` | Maximum number of recent items to retain (min 0, max 50) |

### 2. `chrome.storage.local` (Copy History)
- Key: `history`
- Schema: Array of objects:
  ```json
  [
    {
      "id": "tt0111161",
      "rawId": "tt0111161",
      "title": "The Shawshank Redemption",
      "url": "https://www.imdb.com/title/tt0111161/",
      "copiedAt": 1740500000000
    }
  ]
  ```
- Deduped by ID (moving re-copied items to the top), capped at `historySize`.

---

## 6. Messaging Protocol

| Message Command / Type | Sender $\rightarrow$ Receiver | Payload | Response / Action |
|---|---|---|---|
| `{ cmd: "COPY_ID", explicitId?: string }` | Background/Popup $\rightarrow$ Content | Optional explicit ID | Resolves ID, writes to clipboard, displays toast, records history, responds with `{ ok, raw, id, title, copied }`. |
| `{ cmd: "GET_ID" }` | Popup $\rightarrow$ Content | None | Resolves ID from document/URL without copying; responds with `{ ok, raw, id, title }`. |
| `{ cmd: "GET_TITLE" }` | Popup/Background $\rightarrow$ Content | None | Resolves title info and formatted string; responds with `{ ok, titleInfo, text }`. |
| `{ cmd: "PING" }` | Any $\rightarrow$ Content | None | Responds with `{ alive: true, id }`. |
| `{ type: "COPIED", ... }` | Content $\rightarrow$ Background | `{ id, rawId, title, url }` | Background appends item to `chrome.storage.local` history. |
| `{ type: "COMMAND_RESULT", ... }` | Background $\rightarrow$ Popup/Runtime | `{ ok, id, reason }` | Broadcasts outcome of shortcut command execution. |

---

## 7. Testing & Quality Assurance

- **Unit Smoke Tests:** `test/id-lib.test.mjs`
  - Runs natively with Node.js via `node test/id-lib.test.mjs`.
  - Simulates DOM, JSON-LD, `__NEXT_DATA__` ASTs, and fallback titles across 52 assertions.
- **Current Test Status:** 52 passed, 0 failed.

---

## 8. Performance & Optimization Architecture

1. **Short-Circuit Canonical & Tag Resolution:**
   - Evaluates fast DOM / canonical tags first before parsing large JSON payloads (`__NEXT_DATA__`).
   - JSON-LD (~1KB) prioritized before walking deep Next.js AST trees.
2. **$O(1)$ AST Traversal:**
   - Uses `Set` for visited nodes in recursive walks, avoiding linear array searches and deep memory overhead.
3. **Event-Driven SPA Navigation:**
   - Uses `popstate`, Navigation API, and MutationObserver on `<title>` with debounce, replacing heavy polling with zero-cost event hooks.
4. **DOM Batching:**
   - Uses `DocumentFragment` in popup history rendering to eliminate reflow overhead.
